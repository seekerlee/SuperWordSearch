package me.qingkou.superws;

enum Direction {
    WEST, NORTH, EAST, SOUTH, NORTHWEST, NORTHEAST, SOUTHWEST, SOUTHEAST
}
